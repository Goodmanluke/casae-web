# Casae Web

This is the Next.js frontend for the Casae application.

## Development

```bash
npm install
npm run dev
```

The app will be available at `http://localhost:3000`.

## Build & Start

```bash
npm run build
npm start
```